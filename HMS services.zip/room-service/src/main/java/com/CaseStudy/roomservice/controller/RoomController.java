package com.CaseStudy.roomservice.controller;
 
import com.CaseStudy.roomservice.dto.RoomDTO;
import com.CaseStudy.roomservice.entity.Room;
import com.CaseStudy.roomservice.service.RoomService;
 
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
 
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
 
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;

@RestController
@RequestMapping("/rooms")
public class RoomController {

    @Autowired
    private RoomService roomService;

    // Accessible only by OWNER
    
    @PostMapping
    @PreAuthorize("hasAnyRole('MANAGER', 'OWNER')")
    public Room addRoom(@Valid@RequestBody Room room) {
        return roomService.addRoom(room);
      }
//    @PostMapping
//    @PreAuthorize("hasAnyRole('OWNER', 'MANAGER')")
//    public Room addRoom(@Valid@RequestBody Room room) {
//        return roomService.addRoom(room);
//    }

    
    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('OWNER', 'MANAGER')")
    public Room updateRoom(@Valid@PathVariable Long id, @RequestBody Room room) {
        return roomService.updateRoom(id, room);
    }

    
    
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('OWNER')")
    public void deleteRoom(@PathVariable Long id) {
        roomService.deleteRoom(id);
    }

    // Accessible by OWNER, MANAGER, and RECEPTIONIST
    
    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('OWNER', 'MANAGER', 'RECEPTIONIST')")
    public RoomDTO getRoomById(@PathVariable Long id) {
        Room room = roomService.getRoomById(id);
        return new RoomDTO(
            room.getId(),
            room.getRoomNumber(),
            room.getType(),
            room.getPrice(),
            room.isAvailable()
        );
    }
}
